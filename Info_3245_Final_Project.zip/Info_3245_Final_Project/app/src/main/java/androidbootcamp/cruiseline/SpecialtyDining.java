package androidbootcamp.cruiseline;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class SpecialtyDining extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specialty_dining);

        ImageButton saltyBtn = findViewById(R.id.imgSalt);
        ImageButton shareBtn = findViewById(R.id.imgShare);

        shareBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browser1 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.princess.com/downloads/pdf/ships-and-experience/food-and-dining/curtis-stone/SHARE-by-Curtis-Stone-Menu.pdf"));
                startActivity(browser1);
            }
        });

        saltyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browser2 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.princess.com/ships-and-experience/food-and-dining/specialty-restaurants/the-salty-dog-gastropub/salty-dog-menu.pdf"));
                startActivity(browser2);
            }
        });

    }
}
