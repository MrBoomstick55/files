package androidbootcamp.cruiseline;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Excursions extends AppCompatActivity {
    Spinner sp ;
    Spinner sp2;
    TextView display_data ;

    String sanArray[] = {"No Selection","Trolley Tour(2 Hours, $49.95)","Countryside Vineyards and Wine Tasting(5 hours, $119.95)", "San Diego Zoo(6 Hours, $109.95)"};
    ArrayAdapter adapter1;

    String vicArray[] = {"No Selection","Enchanting Butchart Gardens(3.5 Hours, $99.95)","Craft Beer Breweries Tour(3.25 Hours, $129.95)", "O Canada Highlights Tour(2 Hours, $79.95)"};
    ArrayAdapter adapter2;

    String record= "";

    double cost1 = 0.0;
    double cost2 = 0.0;
    double totalCost = 0.0;

    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_excursions);

        sp = findViewById(R.id.sanDSpinner);
        sp2 = findViewById(R.id.vicSpinner);

        adapter1 = new ArrayAdapter(this,android.R.layout.simple_list_item_1,sanArray);
        adapter2 = new ArrayAdapter(this,android.R.layout.simple_list_item_1,vicArray);

        display_data = findViewById(R.id.txtResult);

        sp.setAdapter(adapter1);
        sp2.setAdapter(adapter2);


        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override

            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                switch (position)

                {

                    case 0:
                        cost1 = 0.0;

                        break;

                    case 1:
                        cost1 = 49.95;

                        break;

                    case 2:
                        cost1 = 119.95;

                        break;

                    case 3:
                        cost1 = 109.95;

                        break;

                }

            }

            @Override

            public void onNothingSelected(AdapterView<?> parent) {

            }

        });

        sp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override

            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                switch (position)

                {

                    case 0:
                        cost2 = 0.0;

                        break;

                    case 1:
                        cost2 = 99.95;

                        break;

                    case 2:
                        cost2 = 129.95;

                        break;

                    case 3:
                        cost2 = 79.95;

                        break;

                }

            }

            @Override

            public void onNothingSelected(AdapterView<?> parent) {

            }

        });

    }


    public void displayResult(View view)

    {

        totalCost = cost1+cost2;
        display_data.setText("$" + String.format("%.2f", totalCost));
    }
}
