package androidbootcamp.cruiseline;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class DeckMap extends AppCompatActivity {

    static String[] decks = {"Deck 5", "Deck 6", "Deck 7", "Deck 16", "Deck 17", "Deck 18"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deck_map);

        Spinner deckSpinner = findViewById(R.id.deckSpinner);
        final ImageView imgDisplay = findViewById(R.id.imgMaps);
        final TextView resultTxt = findViewById(R.id.txtResult);

        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, decks);

        deckSpinner.setAdapter(adapter);

        deckSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                switch (position) {
                    case 0:
                        Log.v("item", (String) parent.getItemAtPosition(position));
                        imgDisplay.setImageResource(R.drawable.floor5);
                        resultTxt.setText("Escapes Travel Café, Future Cruise Sales, " +
                                "International Café, Internet Café, Michelangelo Dining Room, "
                                + "Princess Fine Arts Gallery, The Piazza, Vines Bar");
                        break;
                    case 1:
                        Log.v("item", (String) parent.getItemAtPosition(position));
                        imgDisplay.setImageResource(R.drawable.floor6);
                        resultTxt.setText("Captain's Circle, Casino Bar, " + "Conference Center, Da Vinci Dining Room, " +
                                "Gatsby's Casino, Passenger Services, " + "Princess Theatre, Speakeasy Cigar Lounge," +
                                "The Shops of Princess, Botticelli Dining Room");
                        break;

                    case 2:
                        Log.v("item", (String) parent.getItemAtPosition(position));
                        imgDisplay.setImageResource(R.drawable.floor7);
                        resultTxt.setText("Club Fusion, Crooners Lounge & Bar, Crown Grill, Dance Floor, " +
                                "Explorers Lounge, Library, Photo Gallery, Princess Theatre, " +
                                "Promenade Galleria, Shore Excursions, The Shops of Princess, Wheelhouse Bar");
                        break;

                    case 3:
                        Log.v("item", (String) parent.getItemAtPosition(position));
                        imgDisplay.setImageResource(R.drawable.floor16);
                        resultTxt.setText("Adagio, Aerobics, Beauty Salon, Conference Room, Fitness Center, " +
                                "Lotus Spa, Massage, Movies Under The Stars, SHARE by Curtis Stone, " +
                                "Sauna, Steam Room, Tradewinds, Wedding Chapel");
                        break;

                    case 4:
                        Log.v("item", (String) parent.getItemAtPosition(position));
                        imgDisplay.setImageResource(R.drawable.floor17);
                        resultTxt.setText("Chill Out, Sun Terrace, Teen Lounge, The Sanctuary, Youth Center");
                        break;

                    case 5:
                        Log.v("item", (String) parent.getItemAtPosition(position));
                        imgDisplay.setImageResource(R.drawable.floor18);
                        resultTxt.setText("Skywalkers Nightclub, Movies Under The Stars Seating");
                        break;

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });
    }
}
