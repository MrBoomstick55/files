package androidbootcamp.cruiseline;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String MyPreferences = "MyPrefs";
    public static final String userNameKey ="nameKey";
    public static final String passWordKey = "passKey";
    public static final String deckKey = "deckKey";

    SharedPreferences sharedpreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText userName = findViewById(R.id.editUserName);
        final EditText passwordTxt = findViewById(R.id.editPass);

        final Button login = findViewById(R.id.loginBtn);
        sharedpreferences = getSharedPreferences(MyPreferences, Context.MODE_PRIVATE);

        final String user = userName.getText().toString();
        final String pass = passwordTxt.getText().toString();

        // Attempted to use shared preferences for login but couldn't figure it out properly
        /*SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(userNameKey, "cassidybrodie");
        editor.putString(passWordKey, "pa55word");
        editor.commit();*/


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainActivity.this, Information.class));
            }
        });
    }
}
